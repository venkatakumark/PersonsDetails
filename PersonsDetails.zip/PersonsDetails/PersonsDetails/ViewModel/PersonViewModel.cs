﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace PersonsDetails
{
	public class PersonViewModel : INotifyPropertyChanged
	{

		private ObservableCollection<Person> _persons;

		public ObservableCollection<Person> Persons
		{
			get { return _persons; }
			set
			{
				_persons = value;
				OnPropertyChanged(nameof(Persons));
			}
		}

		private ICollectionView _personView;

		public ICollectionView PersonView
		{
			get { return _personView; }
			set
			{
				_personView = value;
				OnPropertyChanged(nameof(PersonView));
			}
		}

		private ObservableCollection<string> _countries;

		public ObservableCollection<string> Countries
		{
			get { return _countries; }
			set
			{
				_countries = value;
				OnPropertyChanged(nameof(Countries));
			}
		}

		private string _selectedCountry;

		public string SelectedCountry
		{
			get { return _selectedCountry; }
			set
			{
				if (_selectedCountry != value)
				{

					_selectedCountry = value;
					UpdateFilter();
					OnPropertyChanged(nameof(SelectedCountry));
				}
			}
		}

		private SortList _sortSelection;

		public SortList SortSelection
		{
			get { return _sortSelection; }
			set
			{
				_sortSelection = value;
				UpdateSort();
				OnPropertyChanged(nameof(SortSelection));
			}
		}


		public PersonViewModel()
		{
			Persons = new ObservableCollection<Person>();
			PersonView = CollectionViewSource.GetDefaultView(Persons);
			UpdateFilter();
			var csvpath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "PersonsDemo.csv");
			using (var reader = new StreamReader(csvpath))
			using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
			{
				var records = csv.GetRecords<Person>();
				foreach (var record in records)
				{
					Persons.Add(record);
				}
			}
			Countries = new ObservableCollection<string>(Persons.Select(Person => Person.country).Distinct());

		}

		private void UpdateFilter()
		{
			PersonView.Filter = person =>
			{
				if (string.IsNullOrEmpty(SelectedCountry))
					return true;

				return ((Person)person).country == SelectedCountry;
			};

		}

		private void UpdateSort()
		{
			ICollectionView view = CollectionViewSource.GetDefaultView(Persons);

			if (SortSelection == SortList.Name)
			{
				PersonView.SortDescriptions.Clear();
				PersonView.SortDescriptions.Add(new SortDescription("name", ListSortDirection.Ascending));
			}
			else if (SortSelection == SortList.Country)
			{
				PersonView.SortDescriptions.Clear();
				PersonView.SortDescriptions.Add(new SortDescription("country", ListSortDirection.Ascending));
			}
			else
			{
				PersonView.SortDescriptions.Clear();
			}


		}
		private void OnPropertyChanged(string propertyName)
		{
			PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
		}

		public event PropertyChangedEventHandler PropertyChanged;
	}
}
