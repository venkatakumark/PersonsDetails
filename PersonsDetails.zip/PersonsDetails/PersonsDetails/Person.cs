﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonsDetails
{
    public class Person
    {
        public string name { get; set; }
        public string country { get; set; }
        public string phone { get; set; }
    }
    public enum SortList
    {
        [Description("")]
        NOT_SET = 0,
        [Description("Sort by Country")]
        Country,
        [Description("Sort by Name")]
        Name
    }

}
